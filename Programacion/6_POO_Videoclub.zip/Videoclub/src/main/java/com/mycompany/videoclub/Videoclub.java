/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.videoclub;

import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Carlos CG
 */


public class Videoclub {

    public static Persona buscarPersona(LinkedList<Persona> personas, String dni){
        Persona p = null;
        for (int i = 0; i < personas.size(); i++) 
            if(personas.get(i).getDni().equals(dni))
                p = personas.get(i);
        return p;
    }
    /*
    public static int buscarPersona2(LinkedList<Persona> personas, String dni){
        int pos = -1;
        for (int i = 0; i < personas.size(); i++) 
            if(personas.get(i).getDni().equals(dni))
                pos = i;
        return pos;
    }
    */
    
    public static PeliculaSerie buscarPelSer(LinkedList<PeliculaSerie> pelisSeries, int id){
        PeliculaSerie pelSer = null;
        for (int i = 0; i < pelisSeries.size(); i++) 
            if(pelisSeries.get(i).getId() == id)
                pelSer = pelisSeries.get(i);
        return pelSer;
    }
    
    public static LinkedList<Integer> mostrarAlquileresPersona(LinkedList<Alquiler> alquileres, String dni){
        LinkedList<Integer> misAlqui = new LinkedList<Integer>();
        /*
        for (Alquiler alq : alquileres) {
            if(alq.getCli().getDni().equals(dni)){
                System.out.println(alq);
                cont++;
            }
        }
        */
        for (int i = 0; i < alquileres.size(); i++) 
            if(alquileres.get(i).getCli().getDni().equals(dni)){
                if(misAlqui.isEmpty()){
                    System.out.println("Ref. - Info");
                    System.out.println("-----------------------------------------");
                }
                System.out.println(i + " - " + alquileres.get(i));
                misAlqui.add(i);
            }
        
        if(misAlqui.isEmpty()){
            System.out.println("No hay alquileres");
        }
        /*
        for (int i = 0; i < alquileres.size(); i++) {
            if(alquileres.get(i).getCli().getDni().equals(dni)){
                System.out.println(alquileres.get(i));
            }
        }*/
        return misAlqui;
    }
    
    public static void main(String[] args) {
        
        LinkedList<Persona> personas = new LinkedList<Persona>();
        LinkedList<PeliculaSerie> pelisSeries = new LinkedList<PeliculaSerie>();
        LinkedList<Alquiler> alquileres = new LinkedList<Alquiler>();
        
        Scanner numeros = new Scanner(System.in);
        Scanner texto = new Scanner(System.in);
        
        int idPel = 0;
        
        System.out.println("MENÚ VIDEOCLUB");
        int op;
        do{
            System.out.println("¿Qué desea hacer?");
            System.out.println("-----------------------");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Nuevo alquiler");
            System.out.println("3. Fin de alquiler");
            System.out.println("4. Listar alquileres");
            System.out.println("5. Nueva Película/Serie");
            System.out.println("6. Salir");
            
            System.out.print("seleccione una opción(1-6):");
            op = numeros.nextInt();
            
            switch (op) {
                case 1:
                    System.out.println("CREANDO NUEVO CLIENTE:");
                    System.out.print("Introduce dni: ");
                    String dni = texto.nextLine();
                    System.out.println("Introduce el nombre: ");
                    String nombre = texto.nextLine();
                    System.out.println("Introduce los apellidos: ");
                    String apellidos = texto.nextLine();
                    System.out.println("Introduce el teléfono: ");
                    int tlfn = numeros.nextInt();
                    System.out.println("Introduce el email: ");
                    String email = texto.nextLine();
                    System.out.println("Introduce la dirección: ");
                    String dir = texto.nextLine();
                    personas.add(new Persona(dni, nombre, apellidos, tlfn, email, dir));
                    break;
                case 2:
                    System.out.println("CREANDO NUEVO ALQUILER");
                    System.out.println("Introduce el dni del cliente: ");
                    String dni2 = texto.nextLine();
                    System.out.println("Introduce la fecha de inicio: ");
                    String fechaIni = texto.nextLine();
                    System.out.println("Introduce la fecha de finalización: ");
                    String fechaFin = texto.nextLine();
                    System.out.println("Introduce el id de la película: ");
                    int idPelSer = numeros.nextInt();
                    
                    Persona p = buscarPersona(personas, dni2);
                    PeliculaSerie pelSer = buscarPelSer(pelisSeries, idPelSer);
                    if(p != null && pelSer!= null)
                        alquileres.add(new Alquiler(p, fechaIni, fechaFin, pelSer));
                    else
                        System.out.println("EL ALQUILER NO SE HA PODIDO CREAR");
                    break;
                case 3:
                    System.out.println("FINALIZANDO ALQUILER");
                    System.out.println("Introduce el dni del cliente: ");
                    String dni3 = texto.nextLine();
                    LinkedList<Integer> listaAlquileresDni = mostrarAlquileresPersona(alquileres, dni3);
                    if(!listaAlquileresDni.isEmpty()){
                        System.out.print("Introduce la referencia a eliminar: ");
                        int ref = numeros.nextInt();
                        if(listaAlquileresDni.contains(ref))
                            alquileres.remove(ref);
                        else
                            System.out.println("No se puede eliminar el alquiler correspondiente a la ref. introducida");
                    }
                    break;
                case 4:
                    if(alquileres.isEmpty())
                        System.out.println("No hay alquileres actualmente");
                    for (Alquiler alq : alquileres) {
                        System.out.println(alq);
                    }
                    break;
                case 5:
                    System.out.println("CREANDO NUEVA PELÍCULA");
                    System.out.print("Introduce el título: ");
                    String tit = texto.nextLine();
                    System.out.print("Introduce el nombre del/de la director/a: ");
                    String nom = texto.nextLine();
                    int opc;
                    Categoria cat = Categoria.ACCION;
                    do{
                        System.out.println("Selecciona una categoría:(1-COMEDIA | 2-TERROR | 3-ACCION | 4-CIENCIA_FICCION | 5-AVENTURA)");
                        opc = numeros.nextInt();
                        switch (opc) {
                            case 1:
                                cat = Categoria.COMEDIA;
                                break;
                            case 2:
                                cat = Categoria.TERROR;
                                break;
                            case 3:
                                cat = Categoria.ACCION;
                                break;
                            case 4:
                                cat = Categoria.CIENCIA_FICCION;
                                break;
                            case 5:
                                cat = Categoria.AVENTURA;
                                break;
                            default:
                                System.out.println("VALOR FUERA DE RANGO");;
                        }
                    }while(opc < 1 || opc > 5);
                    pelisSeries.add(new PeliculaSerie(idPel, tit, nom, cat));
                    idPel++;
                    break;
                default:
                    System.out.println("POR FAVOR, SELECCIONA UNA OPCIÓN VÁLIDA");;
            }
            System.out.println("");
        }while(op != 6);
        
    }
}
