/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.videoclub;

import java.util.Objects;

/**
 *
 * @author Carlos CG
 */
public class Alquiler {
    
     private Persona cli;
     private String fechaIni;
     private String fechaFin;
     private PeliculaSerie pelSer;
     
     public Alquiler(Persona cli, String fechaIni, String fechaFin, PeliculaSerie pelSer){
         this.cli = cli;
         this.fechaIni = fechaIni;
         this.fechaFin = fechaFin;
         this.pelSer = pelSer;
     }

    public Persona getCli() {
        return cli;
    }

    public void setCli(Persona cli) {
        this.cli = cli;
    }

    public String getFechaIni() {
        return fechaIni;
    }

    public void setFechaIni(String fechaIni) {
        this.fechaIni = fechaIni;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public PeliculaSerie getPelSer() {
        return pelSer;
    }

    public void setPelSer(PeliculaSerie pelSer) {
        this.pelSer = pelSer;
    }

    @Override
    public boolean equals(Object obj) {
        Alquiler alq = (Alquiler) obj;
        return (this.cli.equals(alq.getCli()) && this.fechaIni.equals(alq.getFechaIni()) && this.pelSer.equals(alq.getPelSer()));
    }

    @Override
    public String toString() {
        return "Alquiler[cliente: (dni:" + this.cli.getDni() + ") (Nombre:" + this.cli.getNombre() + "); fecha inicio: " +
                this.fechaIni + "; fecha fin: " + this.fechaFin + 
                "; Película/Serie: (id:" + this.pelSer.getId() + ") (título: " + this.pelSer.getTitulo() + ")]";
    }
     
}
