/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.videoclub;

/**
 *
 * @author Carlos CG
 */
public class PeliculaSerie {
    
    private int id;
    private String titulo;
    private String director;
    private Categoria cat;
    
    public PeliculaSerie(int id, String titulo, String director, Categoria cat){
        this.id = id;
        this.titulo = titulo;
        this.director = director;
        this.cat = cat;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public Categoria getCat() {
        return cat;
    }

    public void setCat(Categoria cat) {
        this.cat = cat;
    }

    @Override
    public boolean equals(Object obj) {
        return id == ((PeliculaSerie)obj).getId();
    }

    @Override
    public String toString() {
        return "PeliculaSerie[id: " + this.id + "; titulo: " + this.titulo +
                "; director/a: " + this.director + "; categoría: " + this.cat + "]";
    }
    
}
